# bounceOffAlgorithm
Algorithm to bounce off two objects
